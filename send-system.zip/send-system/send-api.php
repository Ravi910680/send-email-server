<?php

$servername = "api-db.cibi1nnzyilv.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname45 = "heptera-api";

$send_api_table_conn = mysqli_connect($servername, $username, $password,$dbname45);




use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



function get_get_query_of_con_data($old_query,$con_data){



$get_query=$old_query;

foreach ($con_data as $key => $value) {
	
$get_query.=$key."=".urlencode($value)."&";


}



return $get_query;

}



if($_SERVER['REQUEST_METHOD']==='POST' && empty($_POST)) {
   $_POST = json_decode(file_get_contents('php://input'),true); 
}

$oauth_token=$_POST['oauth_tokn'];


$email=$_POST['data']['email'];
$merg_data=$_POST['data']['to-name'];
$frm_mail=$_POST['data']['from'];
$frm_name=$_POST['data']['from-name'];
$sub_fld=$_POST['data']['subject'];

$lst_id=$_POST['data']['lst_id'];

if($_POST['data']['type_send']=="txt"){

	$cnt_data="text";

$template=$_POST['data']['content'];

}else if($_POST['data']['type_send']=="template"){

$cnt_data=$_POST['data']['content'];

$get_query=get_get_query_of_con_data("",$_POST['usr_data'][0]);

$get_query=get_get_query_of_con_data($get_query,$_POST['data']['dynamic_content'][0]);

$temp_id=rawurlencode($_POST['data']['content']).".php";
$html_temp_data="http://localhost/html/dash/main/api/api_temp/".$temp_id."?".$get_query."lst_name=".$lst_id;


$template=file_get_contents($html_temp_data);


}





require_once "vendor/autoload.php";

$mail = new PHPMailer(true);

//Enable SMTP debugging.
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "email-smtp.us-east-2.amazonaws.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "AKIA4W4EUKY7RI47LWEX";                 
$mail->Password = "BOWO/d0PBBYdXbvENfi4W/jLPufd8895Iw2I/MlGAplV";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to
$mail->Port = 587;                                   

$mail->From = $frm_mail;
$mail->FromName = $frm_name;

$mail->addAddress($email,$merg_data);

$mail->isHTML(true);




$html_con = $template;



$mail->Subject = $sub_fld;
$mail->Body = $html_con;
$mail->AltBody = $sub_fld;

try {
    $mail->send();

    $con_id=$_POST['usr_data'][0]['con_id'];

    $tag=$_POST['data']['tag'];
   
$isrt_od_send_stat_dt="insert into `$oauth_token` (lst_id,con_id,content_dt,tag) value('$lst_id','$con_id','$cnt_data','$tag')";

$send_api_table_conn->query($isrt_od_send_stat_dt);



} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}






?>
<?php






function send_email_camp($conn){


$late_time=get_curr_time();


$late_camp=get_late_camp($conn);









$shed_time=$late_camp["min(camp_shed_time)"];


$shed_time_str=strtotime($shed_time);



if($late_time>$shed_time_str and $shed_time_str!==""){


$temp_id=get_temp_details($conn,$late_camp['camp_contact_id'],$late_camp['camp_name']);



sel_lst_data_frm_db($conn,$late_camp['camp_contact_id'],$temp_id);




}





}



send_email_camp($camp_name_conn);


?>

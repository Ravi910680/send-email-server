<?php
$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$dbname45 = "con_imp";

$con_impo_conn = mysqli_connect($servername, $username, $password,$dbname45);



?>

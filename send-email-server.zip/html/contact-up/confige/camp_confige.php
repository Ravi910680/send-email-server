<?php


$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="camp_email_db";




$camp_name_conn = mysqli_connect($servername, $username, $password,$db);




?>


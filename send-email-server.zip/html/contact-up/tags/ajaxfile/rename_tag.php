<?php

require("../../confige/fileconfige.php");

require("../../confige/managetag.php");
session_start();



$id=$_SESSION["id"];

$listname_api=$_SESSION['listname'];

$old_tg=$_POST["old_tag_name"];
$new_tg=$_POST["new_tag_name"];
$loc_arr=array();

if($new_tg==""){
$sql = "SELECT * FROM `".$listname_api."` where tag LIKE '%".$old_tg."%'";

$result = $conn3->query($sql);

if ($result->num_rows > 0) {	      
      	      // output data of each row
  while($row = $result->fetch_assoc()) {
      $fin_tag_str= str_replace($old_tg,$new_tg,$row["tag"]);


$loc_arr[$row["email"]]=$fin_tag_str;
  }
}

$return_array=json_encode($loc_arr);


}else{

$sql_up_tag="update tag".$id." set tag='".$new_tg."' where id='".$old_tg."'";

if($mngtag->query($sql_up_tag)==TRUE){


echo 1;

}else{

echo 0;

}


}



?>

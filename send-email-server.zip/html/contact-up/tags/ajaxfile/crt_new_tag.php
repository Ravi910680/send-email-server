<?php

require("../../confige/managetag.php");

session_start();

$id=$_SESSION["id"];
$name_tag=$_POST["new_tag"];
$date=date("Y-m-d");

$sql = "INSERT INTO tag".$id." (id, tag, date) VALUES ('', '$name_tag', '$date')";


if ($mngtag->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}





?>

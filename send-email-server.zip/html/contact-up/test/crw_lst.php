<?php

ini_set('memory_limit', '-1');




$dom = file_get_html("https://www.mailgenius.com/", false);




?>

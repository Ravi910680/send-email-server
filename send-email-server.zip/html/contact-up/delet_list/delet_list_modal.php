

<div class="modal fade" id="del_list_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delet Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label style='padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;'>Whish To Delet Template</label>
 <div id='del_list_name' style='color:red;font-weight:700;'></div>
      </div>
      <div class="modal-footer">
        <button type="button" class='bottom-btn'  data-dismiss="modal" style='background:red;'>Close</button>
        <button type="button" class='bottom-btn' id='del_list_fin' ><span style='padding-right:10px;display:none' id='del_load'><i class="fas fa-circle-notch fa-spin" style=''></i></span>Delete Template</button>
      </div>
    </div>
  </div>
</div>


<?php

session_start();

require("../../confige/camp_confige.php");



function get_mail_camp($conn,$id){


$sel_query='select * from camp_name_tbl where id="'.$id.'" ORDER BY camp_shed_time DESC';

$loc_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
    array_push($loc_arr, $row);

  }
} else {
 
}


return $loc_arr;


}


$res_data=array();


$id=$_SESSION['id'];

$res_data['email_camp']=get_mail_camp($camp_name_conn,$id);


print_r(json_encode($res_data));


?>
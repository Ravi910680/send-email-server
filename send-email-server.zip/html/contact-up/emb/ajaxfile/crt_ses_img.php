<?php
session_start();

$_SESSION['img_insta']=$_POST['insta_img'];

echo $_SESSION['img_insta'];

?>

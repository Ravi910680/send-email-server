<?php
  
session_start();
require 'vendor/autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;

$tw_api_key=$_POST['tw_token'];

$tw_ex_tok=explode("#",$tw_api_key);

$acc_tok=$tw_ex_tok[0];
$acc_tok_sec=$tw_ex_tok[1];

$consumerkey = "Ez4QEjTHyepCBVZliPWZoWWnn";
$consumersecret = "Tfu97VINIz7V1VyOZ8KtXCnaXVZ4Q7K22cVfi74yT31Xj6FGq9";


$twitteroauth = new TwitterOAuth($consumerkey, $consumersecret,$acc_tok,$acc_tok_sec);


$user = $twitteroauth->get('account/verify_credentials', ['tweet_mode' => 'extended', 'include_entities' => 'true']);

$pro_tw_usr=$user->profile_image_url_https;
$pro_name_tw=$user->screen_name;

$arr_jsn=['pro_pic_tw'=>$pro_tw_usr,'tw_name'=>$pro_name_tw,'flr'=>$user->followers_count,'flw'=>$user->friends_count];

echo json_encode($arr_jsn);
?>




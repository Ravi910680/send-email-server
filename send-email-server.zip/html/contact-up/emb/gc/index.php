








<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style type="text/css">

.con-fb-connect {
    padding-top: 10%;
    height: 100vh;
    overflow: scroll;
}
.card-img-top{

  margin: auto;
  height: 64px;
  width: 64px;
}


.card{
padding-top: 20px;
    padding-bottom: 20px;

  }
  img.list-img-right {
    height: 36px;
    padding-right: 30px;
  }





.bottom-btn{
  text-align: center;
    height: 40px;
    background: #4a154bd9;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border:1px solid  #4a154bd9;
   width:100%;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}


</style>
<script type="text/javascript">





</script>

<div class='con-fb-connect'>

<div class="card" style="width: 30rem;margin:auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1592640812/google-contacts_ywkv2b.png"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Connect Google Contact Account</h5>
    <p class="card-text">Add Your Google Contact And Saved In Heptera| <sub>list</sub>.</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Get All Email Contact in Heptera</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Select Specific Contact</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add All Contact.</li>
    <li class="list-group-item"><img class='list-img-right' src="https://image.flaticon.com/icons/svg/2800/2800054.svg">Add In List.</li>
  </ul>
  <div class="card-body">
  <button id="authlink" class="googleContactsButton bottom-btn">Connect Google Contact</button>  </div>
</div>

</div>
 <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="https://apis.google.com/js/client.js"></script>
<script src="../ajaxfile/utils.js"></script>



<script type="text/javascript">

var clientId = '97198109466-nejscbb44dk5vfo8ktfcl6n8mns5pmj6.apps.googleusercontent.com';
          var apiKey = 'N9LNXWuNG7-Cit8DWtY2T4zh';
          var scopes = 'https://www.googleapis.com/auth/contacts.readonly';

          $(document).on("click",".googleContactsButton", function(){
            gapi.client.setApiKey(apiKey);
            window.setTimeout(authorize);
          });

          function authorize() {
            gapi.auth.authorize({client_id: clientId, scope: scopes, immediate: false}, handleAuthorization);
          }

            
function handleAuthorization(authorizationResult) {

console.log(authorizationResult);

	if (authorizationResult && !authorizationResult.error) {
             console.log("ravi");
              
new_auth_tok=authorizationResult.access_token;

$.ajax({
                url : "../ajaxfile/sub_acc_token.php",
                type: "POST",
                data : {access_tok:new_auth_tok,access_tp:"gc"}
        }).done(function(response){ 
console.log(response);
if(response){
window.location.href="../../emb/";
}else{


}
        });





            }
          }          




</script>




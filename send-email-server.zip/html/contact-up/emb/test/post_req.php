<?php















function httpPost($url,$params)
{
	$p=0;

  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';

$p=$p+1;
   }


   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, $p);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
          
}  







function twitter_send_post($acc_tok,$row){


$post_data=json_encode($row);


$acc_exp=explode("*", $acc_tok);


$acc_key_exp=explode("#", $acc_exp[0]);


$acc_det=$acc_exp[1];

$acc_tok=$acc_key_exp[0];

$acc_key_sec=$acc_key_exp[1];

$para_arr=array(

	"acc_det"=>$acc_det,
	"acc_tok"=>$acc_tok,
	"acc_tok_sec"=>$acc_tok_sec,
	"post_data"=>$post_data


	);



$url_data="https://heptera.me/dash/main/addcontact/emb/test/curltest.php";

$post=httpPost($url_data,$para_arr);

echo $post;



}

$req=twitter_send_post("1150652678181011456-ukPpFMtTW3AUBcnLzjZae49hZvODtz#mRrBV5ExpuRZkWTmL89xszcE78MkBuarawmO5jxl4ey6Z","");

echo $req;


?>

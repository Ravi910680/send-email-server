<?php
session_start();
require("../../confige/fileconfige.php");

require("../../ajaxfile/phpfile/ip_to_mysql.php");



error_reporting(E_ERROR);




$lst_name=$_SESSION['listname'];


$fld_name=$_POST['fld_name'];
$fld_tp=$_POST['fld_tp'];




$get_txt_tp=get_txt_dt_tp($fld_tp);



$chg_dt_tp="ALTER TABLE `".$lst_name."` ADD ".$fld_name." ".$get_txt_tp." after email";
if ($conn3->query($chg_dt_tp) === TRUE) {
  echo 1;
} else {
  echo $conn3->error;
}











          
         
          
         
        

?>

<div class="modal fade" id="del_fld_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delet Field</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label style='padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;'>Whish To Delet </label>
 <div id='del_fld_name' style='color:red;font-weight:700;'></div>
      </div>
      <div class="modal-footer">
        <button type="button" class='bottom-btn'  data-dismiss="modal" style='background:red;'>Close</button>
        <button type="button" class='bottom-btn' id='del_fld_fin' ><span style='padding-right:10px;display:none' id='del_load'><i class="fas fa-circle-notch fa-spin" style=''></i></span>Delete Template</button>
      </div>
    </div>
  </div>
</div>


<script>


del_fld='';


$(document).on("click",".dlt_trg_icn",function(){
del_fld=$(this).attr("id");

$("#del_fld_name").html(del_fld);

});

$(document).on("click","#del_fld_fin",function(){


$("#del_load").css("display","inline-block");



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_fld.php",
  data: {fld_old_name:del_fld}
}).done(function(response1) {

        if(response1==1){
location.reload();

        }else{

	
$("#del_load").css("display","none");
        }



});




});


</script>

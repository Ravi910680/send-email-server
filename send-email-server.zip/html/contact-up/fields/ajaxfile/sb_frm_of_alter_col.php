<?php

require("../../confige/fileconfige.php");
require("../../ajaxfile/phpfile/ip_to_mysql.php");
$json_str_dt= $_POST['json_str'];
echo $json_str_dt;

$dc_json_dt=json_decode($json_str_dt, true);

print_r($dc_json_dt['Vehicles']);


$get_txt_tp=get_txt_dt_tp($dc_json_dt[$i][2]);
session_start();

$lst_name=$_SESSION['listname'];

foreach ($dc_json_dt['Vehicles'] as $val) {

$get_txt_tp=get_txt_dt_tp($val[2]);




$chg_dt_tp="ALTER TABLE `".$lst_name."` Change ".$val[0]." ".$val[1]." ".$get_txt_tp;
echo $chg_dt_tp;

if ($conn3->query($chg_dt_tp) === TRUE) {
  echo "New record created successfully";
} else {
  echo $conn3->error;
}

}















?>

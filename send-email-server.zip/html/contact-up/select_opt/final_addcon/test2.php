<?php
session_start();
echo $_SESSION['email_data'];
$data=json_decode($_SESSION['email_data']);
print_r($data[0]->email);




?>

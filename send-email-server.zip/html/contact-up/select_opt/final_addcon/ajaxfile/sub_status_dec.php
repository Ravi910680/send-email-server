<?php



function sub_stat_dec($sub_flg){


	if($sub_flg=="subscribe"){
		return 1;
	}else if($sub_flg=="un-subscribe"){
		return 2;
	}else if($sub_flg=="none-subscribe"){

		return 3;
	}else if($sub_flg=="bounced"){
		return 4;

	}




}

function sub_stat_enco($sub_flg){


if($sub_flg==1){
                return "subscribe";
        }else if($sub_flg==2){
                return "un-subscribe";
        }else if($sub_flg==3){

                return "none-subscribe";
        }else if($sub_flg==4){
                return "bounced";

        }



}





?>

<?php


require("../../../confige/email_camp_ana.php");

require("../../../confige/camp_confige.php");



$req_data=$_GET;




function get_all_camp_list($conn,$type,$val){


$ret_arr_tbl=array();

$sel_query='select * from camp_contact_tbl where '.$type.'="'.$val.'"';


$result = $conn->query($sel_query);



if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    


    array_push($ret_arr_tbl, $row);


  }
}




return $ret_arr_tbl;

}





function get_all_tbl_name($all_con_data,$type,$val){


$ret_arr=array();


foreach ($all_con_data as $key => $value) {


if($type=='camp_con_id'){

array_push($ret_arr, $value[$type]."#".$val);

}else{

array_push($ret_arr, $val."#".$value[$type]);

}

	
}



return $ret_arr;




}







$arr_res_data=array('all'=>0);




function set_res_arr_of_loc($conn,$tbl,$gp_by,$othr){





$sel_query='SELECT '.$gp_by.','.$othr.',count(*) as how FROM `'.$tbl.'` GROUP BY '.$gp_by;




$result = $conn->query($sel_query);
$result_flg=$result->num_rows;

$res_db_data=array();

if($result_flg>0){

while($row = $result->fetch_assoc()) {



$GLOBALS['arr_res_data']['all']+=(int)$row['how'];

	
array_push($res_db_data, $row);



}

}



$GLOBALS['arr_res_data'][$gp_by]=$res_db_data;




}














$dash_val=$req_data['path_val'];






if($req_data['src']=='list'){



$all_tbl_lst=get_all_tbl_name(get_all_camp_list($camp_name_conn,'list_id',$dash_val),'camp_con_id',$dash_val);





}else{



$all_tbl_lst=get_all_tbl_name(get_all_camp_list($camp_name_conn,'camp_con_id',$dash_val),'camp_con_id',$dash_val);


}




















foreach ($all_tbl_lst as $key => $value) {
	
if($req_data['type']=='reg'){

  set_res_arr_of_loc($camp_ana_conn,$value,'reg','cnt');


}else if($req_data['type']=='all'){


set_res_arr_of_loc($camp_ana_conn,$value,'reg','cnt');

set_res_arr_of_loc($camp_ana_conn,$value,'cnt','reg');


}


}



print_r(json_encode($arr_res_data));




?>
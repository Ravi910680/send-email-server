<?php
session_start();
require("../../confige/fileconfige.php");


$lst_name=$_SESSION['listname'];
$lst_dis_name=base64_decode(explode("^", $lst_name)[1]);



    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />


<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
   

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}











.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 49%;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}





.header-6RFqy, .wink .header-6RFqy {
    padding: 36px;
    border-bottom: 1px solid #dedddc;


}

.row-2bcC_, .wink .row-2bcC_ {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 10px;

    }

    .title-2V2Vk, .wink .title-2V2Vk {
    margin-bottom: 6px;

}

.byline-1jw7n, .wink .byline-1jw7n {
    -webkit-box-flex: 1;
    -ms-flex: 1 0 0px;
    flex: 1 0 0%;
    color: rgba(36,28,21,.65);
    margin-bottom: 0;
    font-size: 15px;
    padding-right: 20px;
        font-weight: 400;

    }

    .outerContainer-2q3dI, .wink .outerContainer-2q3dI {
    padding: 36px;
    border-bottom: 1px solid #dedddc;

}

.emptyState-3H_ct, .wink .emptyState-3H_ct {
    font-size: 2rem;
    padding-bottom: 24px;
    }

    .container-VHfjh, .wink .container-VHfjh {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: end;
    -ms-flex-align: end;
    align-items: flex-end;
}

.countHeader-oIFUQ, .wink .countHeader-oIFUQ {
    font-weight: 500;
    margin-bottom: 6px;
    font-size: 30px;

    }

    .inactiveCountHeader-2Sfab, .wink .inactiveCountHeader-2Sfab {
    font-weight: 500;
    color: rgba(36,28,21,.65);
}

.dateLabel-8C5Mp, .wink .dateLabel-8C5Mp {
    margin-top: 12px;
    margin-bottom: 0;
    font-size: 13px;
    }
    .statisticsListContainer-2apDH, .wink .statisticsListContainer-2apDH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1 1 0%;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-end;
}

.statisticContainer-HQvNi, .wink .statisticContainer-HQvNi {
    margin-left: 36px;
    }


    .ico-card-head{
    	font-size: 30px;
    margin-right: 20px;
    color: #4a154bfa;
    }

.circle_othe_inst_ico{
  font-size: 30px !important;
  color: black;
  margin-right: 20px;
}


span.tag-name-dis {
    font-size: 20px;
    color: black;
    font-weight: 500;

  }

  .all-tag-cnt-dsg{
    max-height: 400px;
    overflow: scroll;
  }

  .marg-bot{
    margin-bottom: 20px;
  }

  span.had-ln-dt {
    color: #241c15;
    font-size: 15px;
    font-weight: 600;

  }

  img.img-loc-thumb {
    width: 60px;
    margin-right: 20px;
    border-radius: 50%;

  }

  .chrt_dsg{
    max-width: 100%;
    padding: 20px;
  }
  .chrt_con_main{
    width: 49%;
    display: inline-block;

  }




#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}



</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <?php require("../../confige/header/header.php");?>


<div class='main-content' id='main-loader-containre'>


	<div class="container "  style="">



  	<div class="row head-con-rw">

<div class="head-dash">

List Overview
</div>

<div class="btn-con-top" style="text-align:right">
	<button class="btn_hover_clr tooltip2 com-for-lnk" data-for-serv='0'  data-target-link="https://contact.sycista.com/contact/mngc/#mngc" style="float:none">Manage <?php echo $lst_dis_name;?> <i class="fa-long-arrow-right  fal" aria-hidden="true"></i></button>





	</div>

  	</div>





</div>



<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card">
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-user-chart ico-card-head" aria-hidden="true" ></i><h3 class="title-2V2Vk">Recent growth&nbsp;</h3></div><div class=""><p class="byline-1jw7n">New contacts added to this audience in the last days.</p></div></header>


  <section class="outerContainer-2q3dI"><div class="container-VHfjh"><div><h2 class="countHeader-oIFUQ" id='new_con_cnt'>0</h2><p class="inactiveCountHeader-2Sfab">New Contacts</p><p class="dateLabel-8C5Mp">From Aug 18, 2020 to Sep 17, 2020</p></div><div class="statisticsListContainer-2apDH"><div class="statisticContainer-HQvNi"><h3 class="h4 countHeader-oIFUQ" id='all_sub_cnt'>0</h3><span class="inactiveCountHeader-2Sfab">Subscribed</span></div><div class="statisticContainer-HQvNi"><h3 class="h4 countHeader-oIFUQ" id='all_oth_cnt'>0</h3><span class="inactiveCountHeader-2Sfab">Non</span></div></div></div></section>



  <div class="container-2GnNH"><i class="fal fa-plus-circle circle_othe_inst_ico"></i><span><a href="/account/connected-sites/app-selection/">Use our Managment APi <i class="fal fa-external-link" aria-hidden="true"></i></a> For add contact in list throught your system easily.</span>
</div>






<div class="container-2GnNH"><i class="fal fa-plus-circle circle_othe_inst_ico"></i><span><a href="/account/connected-sites/app-selection/">Connect your Cloud Account<i class="fal fa-external-link" aria-hidden="true"></i></a> Import Contact from File or contact that store in Cloud </span>
</div>







</div>



<div class="card" style="margin-left: auto;">
  
  
<header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-user-tag ico-card-head"></i><h3 class="title-2V2Vk">Tag&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Your contacts, organized by your tags.Learn more about tags</p></div></header>

<div class="container-2GnNH"><i class="fal fa-plus-circle circle_othe_inst_ico" aria-hidden="true"></i><span><a href="../">Add tag</a> tag your audiance.</span>
    
    
    <span class="tag-name-dis" style="margin-left: auto;font-size: 13px;"> 
    
    Manage Tag
    
    <i class="fal fa-long-arrow-right" aria-hidden="true"></i> </span>
    
</div>


<div id='tag_dt_over_lst' class='all-tag-cnt-dsg'>




</div>





</div>


</div>





<div class="container row marg-bot" style="margin:auto;margin-bottom:20px;">

  <div class="card" style='width:100%'>
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-globe-asia ico-card-head"></i><h3 class="title-2V2Vk">Prediction Anatomy&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Your subscribers, broken down by how often they open and click your emails.</p></div></header>


<div class="main-all-chrt_con">
<div class='chrt_con_main'>

<canvas class='chrt_dsg' id='hour_chrt' style='max-width:50%,
    padding: 20px;'  width=''></canvas>
</div>

<div class='chrt_con_main'>


<canvas class='chrt_dsg' id='age_chrt'></canvas>

</div>


</div>

</div>

</div>






<div class="container row marg-bot" style="margin:auto;">

  <div class="card">
  <header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-mouse-alt ico-card-head"></i><h3 class="title-2V2Vk">Marketing Enagagment&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Your subscribers, broken down by how often they open and click your emails.</p></div></header>


  <div class="container-2GnNH"><span class="circle_othe_inst_ico"> 0% </span> 

<p class="byline-1jw7n"><span class="had-ln-dt">Rarely</span><br>Your percentage of subscribers who are highly engaged and often open and click your emails.</p><span class="tag-name-dis" style="margin-left: auto;"> <i class="fal fa-paper-plane" aria-hidden="true"></i> </span> </div>


<div class="container-2GnNH"><span class="circle_othe_inst_ico"> 0% </span> 

<p class="byline-1jw7n"><span class="had-ln-dt">Often</span><br>Your percentage of subscribers who are moderately engaged and sometimes open and click your emails. </p><span class="tag-name-dis" style="margin-left: auto;"> <i class="fal fa-paper-plane" aria-hidden="true"></i> </span> </div>


<div class="container-2GnNH"><span class="circle_othe_inst_ico"> 100% </span> 

<p class="byline-1jw7n"><span class="had-ln-dt">Mostly</span><br>Your percentage of subscribers who are not very engaged and rarely open and click your emails.</p><span class="tag-name-dis" style="margin-left: auto;"> <i class="fal fa-paper-plane" aria-hidden="true"></i> </span> </div>











</div>












<div class="card" style="margin-left: auto;">
  
  
<header class="header-6RFqy"><div class="row-2bcC_"><i class="fal fa-map-marker-check ico-card-head"></i><h3 class="title-2V2Vk">Top Location&nbsp;</h3></div><div class=""><p class="byline-1jw7n">Based on your contact’s IP address when they interact with your</p></div></header>


<div id='res_locate_data' class=''>



  <div id="con-of-all-chrt-and-ana-dt"><div class="not-fd-suf-data" style="text-align: center;margin-bottom: 40px;"> <img src="https://res.cloudinary.com/heptera/image/upload/v1606727401/addcontact/10_Growth_vrdpjv.svg" style="
    height: 300px;
"> <div class="suf-data-nf" style=" font-size: 14px; font-weight: 700; color: black; ">Your List Campign Not Collected Sufficient data</div> </div></div>

</div>







</div>









</div>



  
</div>




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
 


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.bundle.min.js"></script>

  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  
  
  
</body>











</html>







<script type="text/javascript">



get_email_api="<?php echo $lst_name; ?>";








recent_date='';
recent_growth={all:0,sub:0,oth:0};



tag_arr_dis_data={};





pred_gend={m:0,f:0};

pred_age={m:{age25:0,age35:0,age45:0,age55:0,age65:0},f:{age25:0,age35:0,age45:0,age55:0,age65:0}};


function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}



$(document).ready(function(){




	tag_data_init_arr(function(){
	
console.log("ravi");	
	
	jQuery.get('../../mngc/rahul1.php?apicode_main='+get_email_api, function(data2) {



var prev_date = new Date();
prev_date.setDate(prev_date.getDate() - 1);

var date = new Date(prev_date);

recent_date=formatDate(date);





           set_overvew_data_on_scr(data2);





  })
	
	
	
	
	
	
	
	
	
	
	});






})



function set_overvew_data_on_scr(data){



arr_cont_data=JSON.parse(data);



init_all_con_acc_data(arr_cont_data,function(){










init_locate_data();

console.log(tag_arr_dis_data);


drw_chrt_of_age();


dis_tag_data();


dis_recent_growth_data();



draw_gend_chart();











})


}







function init_all_con_acc_data(arr_cont_data,callback){



	for (var i = 0; i < arr_cont_data.length; i++) {


rw_data=arr_cont_data[i];

console.log(rw_data);

init_recent_growth(rw_data);

init_tag_data(rw_data);



init_gend_data(rw_data);


init_age_data(rw_data);


}


callback();

}







function init_age_data(row){

int_age=parseInt(row['age_pre']);

int_gend=row['gender_pre'];







if(int_age<25){



pred_age[int_gend]['age25']+=1;


}else if(int_age<35){

  pred_age[int_gend]['age35']+=1;



}else if(int_age<45){

  pred_age[int_gend]['age45']+=1;

}else if(int_age<65){

pred_age[int_gend]['age55']+=1;


}else{

pred_age[int_gend]['age65']+=1;

}




}





function init_gend_data(row){


if(row['gender_pre']=='f'){


pred_gend.f+=1;



}else{


pred_gend.m+=1;


}



}




function tag_data_init_arr(callback){




jQuery.get('./ajaxfile/get_tag_name.php', function(data2) {


console.log(data2);
tag_arr_id_data=JSON.parse(data2);


tag_arr_dis_data=tag_arr_id_data[0];

console.log(tag_arr_dis_data);

  })

callback();


}



function init_locate_data(){




jQuery.get('./ajaxfile/get_location_data.php?src=list&path_val='+get_email_api+'&type=reg', function(data2) {

str_append='';


console.log(data2);


res_data=JSON.parse(data2);



for (var i = 0; i < res_data['reg'].length; i++) {
  
loop_data=res_data['reg'][i];



if(i%2==0){

img='200/200';

}else{

img='199/199';

}


str_append+='<div class="container-2GnNH"><img class="img-loc-thumb" src="https://picsum.photos/'+img+'" style=" "> <p class="byline-1jw7n"><span class="tag-name-dis">'+loop_data['reg']+'</span><br><span class="inactiveCountHeader-2Sfab" style=" margin-bottom: 0px; font-size: 15px; ">'+loop_data['cnt']+'</span></p><span class="tag-name-dis" style="margin-left: auto;"> 20%</span> </div>';


};





$("#res_locate_data").html(str_append);

  })

}









function dis_tag_data(){

str_append='';

console.log(tag_arr_dis_data);

for ( property in tag_arr_dis_data) {


str_append+='<div class="container-2GnNH"><span class="circle_othe_inst_ico"> '+tag_arr_dis_data[property]+' </span> <span class="tag-name-dis"> '+property+'</span><span class="tag-name-dis" style="margin-left: auto;"> <i class="fal fa-paper-plane" aria-hidden="true"></i> </span> </div>';
  
}



$("#tag_dt_over_lst").html(str_append);


}




function init_tag_data(rw_data){

	

console.log(tag_arr_dis_data);

rw_data_tag=rw_data['tag'];

for (var i = 0; i < rw_data_tag.length; i++) {
  
tag_arr_dis_data[rw_data_tag[i]]+=1;

};




}








function init_recent_growth(rw_date){




if(rw_date['crt_date']==recent_date){

recent_growth.all+=1;

if(rw_date['substatus']=='1'){

recent_growth.sub+=1;

}else{

recent_growth.oth+=1;


}


}



}

function dis_recent_growth_data(){


$("#new_con_cnt").html(recent_growth.all);

$("#all_oth_cnt").html(recent_growth.oth);

$("#all_sub_cnt").html(recent_growth.sub);


}




function draw_gend_chart(){






new Chart(document.getElementById("hour_chrt"),{
  "type":"doughnut",
  "data":{
    "labels":["Male","Female"],
  "datasets":[{"label":"My First Dataset","data":[pred_gend.m,pred_gend.f],
  "backgroundColor":["rgb(249, 127, 80)","rgb(79, 19, 94)"]}]


},
"options" : {
        "percentageInnerCutout": 40
    }




});


}






function drw_chrt_of_age(){




console.log(pred_age);


var ctx = document.getElementById('age_chrt').getContext('2d');

var mixedChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
      labels: ['18-25', '25-35', '35-45', '55-65','65+'],
        datasets: [{
          label:'Male',


            backgroundColor:"rgb(249, 127, 80)",
            data: [pred_age['m']['age25'], pred_age['m']['age35'], pred_age['m']['age45'], pred_age['m']['age55'],pred_age['m']['age65']],
            
        }, {
          label:'female',
            backgroundColor:"rgb(79, 19, 94)",
            data: [pred_age['f']['age25'], pred_age['f']['age35'], pred_age['f']['age45'], pred_age['f']['age55'],pred_age['f']['age65']],
            
           
        }],
        
    },

    options: {
       
      barRoundness: 1,
          
          
          responsive: true,
          scales: {
    yAxes: [{
        gridLines: {
            display: false
            
        },
        
        stacked: true

    }],
    xAxes: [{
        ticks: {
            beginAtZero: true,
            callback: function(value, index, values) {
                return '';
            },
        },
        gridLines: {
            display: false,
            drawBorder: false,
        },
        stacked: true
    }],
},

        }
    
});



}


</script>




























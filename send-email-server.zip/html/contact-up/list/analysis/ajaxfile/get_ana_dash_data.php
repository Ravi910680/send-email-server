<?php



session_start();
require("../../../confige/email_camp_ana.php");

require("../../../confige/camp_confige.php");


$all_count=array('click_count'=>0,'open_count'=>0);

$arr_mnt=array('click'=>array_fill(1, 12, 0),'open'=>array_fill(1, 12, 0));

$arr_days=array('click'=>array("Sun"=>0,"Mon"=>0,"Tue"=>0,"Wed"=>0,"Thu"=>0,"Fri"=>0,"Sat"=>0),'open'=>array("Sun"=>0,"Mon"=>0,"Tue"=>0,"Wed"=>0,"Thu"=>0,"Fri"=>0,"Sat"=>0));

$arr_hr=array('click'=>array_fill(1, 24, 0),'open'=>array_fill(1, 24, 0));





$flg_not_fd=0;


function get_all_camp_list($conn,$type,$val){


$ret_arr_tbl=array();

$sel_query='select * from camp_contact_tbl where '.$type.'="'.$val.'"';

$result = $conn->query($sel_query);


if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    
    array_push($ret_arr_tbl, $row);


  }
}




return $ret_arr_tbl;

}







function get_all_tbl_name($all_con_data,$type,$val){


$ret_arr=array();


foreach ($all_con_data as $key => $value) {


if($type=='camp_con_id'){

array_push($ret_arr, $value[$type]."#".$val);

}else{

array_push($ret_arr, $val."#".$value[$type]);

}

	
}


return $ret_arr;




}



function get_all_data_of_tbl($conn,$tbl_name){


$sel_query='select * from `'.$tbl_name.'`';


$result = $conn->query($sel_query);



if ($result->num_rows > 0) {

	$GLOBALS['flg_not_fd']=1;
	$flg_type_name='click';
  
  while($row = $result->fetch_assoc()) {
    
   
 $date = $row['act_date'];


$month = date('m', strtotime($date));

$day = date('D', strtotime($date));

$hour = date('H', strtotime($date));


   if($row['act']=='1'){

  $flg_type_name='open';


}

$GLOBALS['all_count'][$flg_type_name.'_count']+=1;

 $GLOBALS['arr_mnt'][$flg_type_name][(int)$month]+=1;

$GLOBALS['arr_days'][$flg_type_name][$day]+=1;

$GLOBALS['arr_hr'][$flg_type_name][(int)$hour]+=1;




  }
}


}




function rem_idx_frm_arr($arr){
$ret_arr=array();
	foreach ($arr as $key => $value) {
		
array_push($ret_arr, $value);

	}


	return $ret_arr;
}







$geted_data=$_GET;




$dash_val=$geted_data['path_val'];



if($geted_data['src']=='list'){


$all_tbl_lst=get_all_tbl_name(get_all_camp_list($camp_name_conn,'list_id',$dash_val),'camp_con_id',$dash_val);





}else{



$all_tbl_lst=get_all_tbl_name(get_all_camp_list($camp_name_conn,'camp_con_id',$dash_val),'camp_con_id',$dash_val);


}




foreach ($all_tbl_lst as $key => $value) {
	
  get_all_data_of_tbl($camp_ana_conn,$value);


}







if($flg_not_fd==1){

$res_arr=array();



$res_arr['month']['click']=rem_idx_frm_arr($arr_mnt['click']);
$res_arr['month']['open']=rem_idx_frm_arr($arr_mnt['open']);
$res_arr['day']['click']=rem_idx_frm_arr($arr_days['click']);
$res_arr['day']['open']=rem_idx_frm_arr($arr_days['open']);
$res_arr['hr']['click']=rem_idx_frm_arr($arr_hr['click']);
$res_arr['hr']['open']=rem_idx_frm_arr($arr_hr['open']);
$res_arr['count']=$all_count;


print_r(json_encode($res_arr));



}else{

	echo 0;
}

?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
<title>Export Google Contacts Using PHP</title>
 
</head>
<body>
 
<div class="col-sm-6 col-md-4 col-lg-2">
<div class="col-sm-6 col-md-4 col-lg-2">
 
<header class="col-sm-6 col-md-4 col-lg-2">
<center>
<h2>Export Gmail Contacts With Google Oauth PHP</h2>
</center>
</header>
<hr>
<div  class="col-sm-6 col-md-4 col-lg-2">
<center>
<h3 id ="sign">Sign In with Google for retrieving Contacts</h3>
<div class="col-sm-6 col-md-4 col-lg-2">
<a href="https://accounts.google.com/o/oauth2/auth?client_id=419453657110-66e7b4o0ld6d04cqo04ubf840nk8mgdv.apps.googleusercontent.com&redirect_uri=http://www.heptera.tech/callback.php&scope=https://www.google.com/m8/feeds/&response_type=code">Export from Gmail</a>
</div>
</center>
</div>
</div>
</div>
 
</body>
</html>
<?php  
session_start();
require("../../../confige/fileconfige.php");
if(isset($_POST['filename'])){
    $status=0;
 if(!empty($_FILES['file']['name']))
{
    
 $filename = explode(".", $_FILES['file']['name']);
  if($filename[1] == 'csv')
  {

$filenoencode=$_POST["filename"];
$id=$_SESSION["id"];
      $checkpres = "SELECT * FROM filedetails WHERE id='$id' AND filename='$filenoencode'";
$checkres = $conn2->query($checkpres);
$rowcheck=mysqli_num_rows($checkres);





if($rowcheck==0){







      $filename=$id."^".$_POST["filename"];
      $file_data = fopen($_FILES['file']['tmp_name'], 'r');
      $row = fgetcsv($file_data);
      $collom=count($row);
       $tblsql = "CREATE TABLE `".$filename."`(
      email VARCHAR(50) NOT NULL,id INT(2)  PRIMARY KEY, 
        fname VARCHAR(30),
        lname VARCHAR(30),
        addr VARCHAR(255),
        phonr bigint(12),
        bday DATE,
        tag INT(5),
        substatus BOOLEAN,source INT(2)

        
        )";


$recordtimes=0;





if ($conn3->query($sql) === TRUE) {


$findmail=0;

    while($row = fgetcsv($file_data)){
$f=0;
$innermail=$x;
if($f==0){


}

if (filter_var($row[$innermail], FILTER_VALIDATE_EMAIL)) {
$insertdatasql = "INSERT INTO `".$filename."` VALUES ('$row[$innermail]', '$row[2]','$row[3]','$row[4]','$row[5]','$row[6]')";

}else{
for ($x = 0; $x < $collom; $x++){
           if (filter_var($row[$x], FILTER_VALIDATE_EMAIL)) {

$insertdatasql = "INSERT INTO `".$filename."` VALUES ('$row[$x]', '$row[2]','$row[3]','$row[4]','$row[5]','$row[6]')";

break;
           }
}


}












if ($conn3->query($insertdatasql) === TRUE) {
    $recordtimes=$recordtimes+1;}
      }




      
      $insertfilename = "INSERT INTO filedetails (id, filename, extra) VALUES ('$id', '$filenoencode', '$recordtimes')";
$conn2->query($insertfilename);
      echo "<div class='card bg-success text-white'><div class='card-body'>inserted ".$recordtimes." records in file</div></div>";
} else {
    
    $status=1;
    
}
      
}else{
    $status=2;


}

  }else{
    $status=3;
     
  }

}
echo $status;
}else{





    
}


?>
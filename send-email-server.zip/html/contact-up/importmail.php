<?php
session_start();


echo $_SESSION['email_data'];
?>

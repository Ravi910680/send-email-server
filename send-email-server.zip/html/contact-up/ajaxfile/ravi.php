<style>
td{
vertical-align: middle;
}


.dot-desgn {
    padding: 15px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    


}

.center-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #17b31d;
}
</style>
<div class='container' style='padding:0px;border: 1px solid #dedddc;
    border-radius: 5px;
    margin: 20px 0px;' >

<?php



$query="SELECT * FROM filedetails WHERE id='$id'";
$result = $conn2->query($query);

if ($result->num_rows > 0) {
    // output data of each row
    ?>
<div class='con-of-tbl data-tbl-db' style='background:white;border-radius:4px;overflow-y:scroll;'>
<table class="table table-padding" style='text-align:left;'>
  
  <tbody>

    <?php
    while($row = $result->fetch_assoc()) {
        
	    $filename=explode("^",$row['filename']);
	 $name_of_file=base64_decode($filename[1]);  
        ?>
        
  
    <tr style='border:none;' class=''>
<td align='center' style='border:none;padding:0px;'><div class='icon-data-con' style="padding-right:20px;">
  

<div class="dot-desgn" style="
">
<div class="center-dot">
    
    </div>

</div>


</div></td>
      <td style='vertical-align: middle;border:none;'><div class='tbl-main-head'><?php echo $name_of_file;?></div></td>
      <td style='vertical-align: middle;border:none;'><?php echo $row["extra"];?></td>
      <td style='vertical-align: middle;border:none;' id="<?php echo $row['filename'];?>" class='opt_on_list contact tbl-link-clr hove_fad'><svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M8 11C10.2091 11 12 9.20914 12 7C12 4.79086 10.2091 3 8 3C5.79086 3 4 4.79086 4 7C4 9.20914 5.79086 11 8 11ZM8 9C9.10457 9 10 8.10457 10 7C10 5.89543 9.10457 5 8 5C6.89543 5 6 5.89543 6 7C6 8.10457 6.89543 9 8 9Z" fill="currentColor" /><path d="M11 14C11.5523 14 12 14.4477 12 15V21H14V15C14 13.3431 12.6569 12 11 12H5C3.34315 12 2 13.3431 2 15V21H4V15C4 14.4477 4.44772 14 5 14H11Z" fill="currentColor" /><path d="M18 7H20V9H22V11H20V13H18V11H16V9H18V7Z" fill="currentColor" /></svg></td>
      <td  style='vertical-align: middle;border:none;' data-modal-trigger='del_lst_modal' id="<?php echo $row['filename'];?>" class='dltc tbl-link-clr del_list_name hove_fad del-mdl-cls-btn'><svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor" /><path d="M9 9H11V17H9V9Z" fill="currentColor" /><path d="M13 9H15V17H13V9Z" fill="currentColor" /></svg></td>
      <td style='vertical-align: middle;border:none;'  ><button class="bottom-btn back_wt_con com-for-lnk" data-for-serv="0" data-for-red="false" data-target-link="https://contact.sycista.com/contact/ajaxfile/crtseslist.php?requestoflist=<?php echo $row['filename'];?>&red_url=https://contact.sycista.com/contact/list/overview/#list/overview"> Manage List <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.0378 6.34317L13.6269 7.76069L16.8972 11.0157L3.29211 11.0293L3.29413 13.0293L16.8619 13.0157L13.6467 16.2459L15.0643 17.6568L20.7079 11.9868L15.0378 6.34317Z" fill="currentColor" /></svg></button></td>      

    </tr>
    
 
<?php
    }
    ?>

</tbody>

</table>
</div>
    <?php
} else {
    ?>



<style>
.not-f-text{

width: 500px;
    margin: 0px auto;
    padding: 40px;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;
}

.not-f-btn{

background:#0b646d;
border:none;
outline:none;
height:50px;
padding-left:10px;padding-right:10px;
font-weight:700;
color:white;
}
.not-f-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#0e7480;

}


</style>

<div class="not-fd-data">

<img src="https://res.cloudinary.com/heptera/image/upload/v1600235648/addcontact/list-get_nyza6e.png" style='width:300px;'>
<div class='not-f-text' >
Nothing in your List directory. if you make clustered list of user please create list.
</div>
<button data-toggle="modal" data-target="#crtlistname" class="btn_hover_clr" style="float:none"><i class="fas fa-plus" style='padding-right:10px;'></i>create list</button>
</div>

<?php
}
?>




</div>


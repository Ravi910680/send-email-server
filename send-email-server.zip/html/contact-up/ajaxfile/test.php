

<?php
session_start();
require("../../../confige/fileconfige.php");

$id=$_SESSION["id"];

$query="SELECT * FROM filedetails WHERE id='$id'";
$result = $conn2->query($query);


if ($result->num_rows > 0) {
    // output data of each row
  }



?>

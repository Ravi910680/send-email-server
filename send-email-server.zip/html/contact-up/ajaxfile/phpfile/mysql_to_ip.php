<?php


function get_mysql_to_ip($data_type){


	if($data_type=='varchar'){

		return 'text';
	}else if($data_type=='date'){
		return 'date';
	}else if ($data_type=='bigint' || $data_type=='int'){
		return 'number';
	}

}







?>

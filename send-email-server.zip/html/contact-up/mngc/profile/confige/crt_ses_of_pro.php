<?php
session_start();

$_SESSION['pro_email']=$_GET['pro_email_req'];
$_SESSION['pro_id']=$_GET['pro_id'];

header("location: https://contact.sycista.com/contact/mngc/profile/#mngc");



?>

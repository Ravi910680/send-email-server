<?php


session_start();

require("../../../confige/fileconfige.php");





$id=$_SESSION['id'];


$lst_name=$_SESSION['listname'];

$email_pro=$_SESSION['pro_email'];




function str_of_update($data_up_fld){

$str_up="";

foreach($data_up_fld as $x => $val) {


	

$str_up.=$x."='".$val."',";



}

return $str_up;


}


$up_str_fld=str_of_update(json_decode($_POST['data']));

$up_str_fld=substr($up_str_fld, 0, -1);

$up_query="update `$lst_name` set ".$up_str_fld." where email='$email_pro'";





if ($conn3->query($up_query) === TRUE) {
  echo 1;

  $_SESSION['pro_email']=$email_pro;
} else {
  echo 0;
}



?>

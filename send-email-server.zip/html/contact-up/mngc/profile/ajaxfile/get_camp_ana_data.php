<?php



session_start();
require("../../../confige/email_camp_ana.php");


$pro_id=$_SESSION['pro_id'];


$lst_name=$_SESSION['listname'];


$camp_data=$_GET['camp_data'];





?>

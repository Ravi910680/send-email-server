<?php



function get_src_str($geted_arr){
	
	$str_ret="";

for($i=0;$i<count($geted_arr);$i++){
	
$str_ret.="( tag like '%".$geted_arr[$i]."%')";



if($i<count($geted_arr)-1){
	
$str_ret.=" and ";

}else{
	


}







}

return $str_ret;



}


function get_email_col($list_id){
require("../../confige/fileconfige.php");


        $get_col_query="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='storefile' AND `TABLE_NAME`='".$list_id."'";

        $query = $conn3->query($get_col_query);

while($row = $query->fetch_assoc()){


        $result[] = $row;
}

// Array of all column names
$columnArr = array_column($result, 'COLUMN_NAME');

return $columnArr;



}






session_start();


require("../../confige/fileconfige.php");

require("../../confige/managetag.php");

require("./get_tag_data.php");

$listname_api=$_SESSION['listname'];

$json_filt_data=$_POST['filt_tag'];

$arr_filt_data=json_decode($json_filt_data);




$get_col=get_email_col($listname_api);



$str_of_src_data=get_src_str($arr_filt_data);



$sql = "SELECT * FROM `".$listname_api."` where  ".$str_of_src_data. "and arch=0";



$result = $conn3->query($sql);
$a=array();
if ($result->num_rows > 0) {
$i=0;
    // output data of each row
    while($row = $result->fetch_assoc()) {


for($i=0;$i<count($get_col);$i++){


$row_array[$get_col[$i]] = $row[$get_col[$i]];


}


$tag_val=array();
$tag_arr=explode(",",$row_array["tag"]);



for ($i=0; $i <count($tag_arr)-1 ; $i++) {

array_push($tag_val,$geted_tag_array[0][$tag_arr[$i]]);

}



$row_array["tag"]=$tag_val;






array_push($a,$row_array);
    }



  }
$json_arr=json_encode($a);
echo $json_arr;





?>

<?php

session_start();


require("../../confige/fileconfige.php");
require("../../confige/managetag.php");
require("../../confige/segment_confige.php");
$lst_name=$_SESSION['listname'];

$geted_array=$_POST["requestoflist"];


$dec_of_data=json_decode($geted_array);


$stat_of_act=$_POST["get_stat_act"];
if($stat_of_act=="segment"){

        $segment_data=$_POST["seg_name"];
        $drp_rw="delete from segment_data where id='".$segment_data."'";

        $seg_conn->query($drp_rw);




}


foreach($dec_of_data as $x => $val) {
$tag_val_data=$val;       

$sql = "UPDATE `".$lst_name."` SET ".$stat_of_act."='$tag_val_data' WHERE email='$x'";

echo $sql;
if ($conn3->query($sql) === TRUE) {

}





}


?>

<?php


require("../../../confige/fileconfige.php");
$get_code=$_GET['apicode'];





$sql = "SELECT email FROM `".$get_code."`";
$result = $conn3->query($sql);
$email_con_array=array();
if ($result->num_rows > 0) {
   
    // output data of each row
    while($row = $result->fetch_assoc()) {

$str_for_data.="<tr style='height: 49px;'><th class='email-con' style='width: 256px;'><div class='eml-con'>".$row['email']."</div></th></tr>";
array_push($email_con_array,$row['email']);
    }



  }
$json_arr=json_encode($email_con_array);
echo $json_arr;





?>
